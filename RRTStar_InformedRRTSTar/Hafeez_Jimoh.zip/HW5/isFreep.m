function in = isFreep(q,A);
%     plot(A);
%     hold on
    [in] = ~isinterior(A,q(1),q(2));
end

